package main

import "github.com/johnearl92/xendit-ta.git/cmd"

var version = "dev"

func main() {
	cmd.Execute(version)
}
